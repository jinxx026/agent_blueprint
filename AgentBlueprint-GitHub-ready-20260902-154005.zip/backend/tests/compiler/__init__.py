"""Blueprint Compiler tests."""
